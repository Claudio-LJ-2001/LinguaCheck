package analizador;

public interface sym {
    int EOF = 0;
    int ERROR = 1;
    int PRONOUN = 2;
    int VERB = 3;
    int NOUN = 4;
}
