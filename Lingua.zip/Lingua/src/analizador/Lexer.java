package analizador;

import java_cup.runtime.*;
import java.io.*;

public class Lexer {
    private final Reader reader;
    private int yychar = 0;

    public Lexer(Reader reader) {
        this.reader = reader;
    }

    public Symbol next_token() throws IOException {
        int c = reader.read();
        while (c != -1 && Character.isWhitespace(c)) {
            c = reader.read();
            yychar++;
        }

        if (c == -1) return new Symbol(sym.EOF);

        StringBuilder sb = new StringBuilder();
        while (c != -1 && !Character.isWhitespace(c)) {
            sb.append((char) c);
            c = reader.read();
            yychar++;
        }

        String lexema = sb.toString().toLowerCase();

        switch (lexema) {
            case "i": case "you": case "he": case "she": case "we": case "they":
                return new Symbol(sym.PRONOUN, yychar, yychar + lexema.length(), lexema);
            case "eat": case "drink": case "like": case "see": case "read": case "write": case "go": case "come":
                return new Symbol(sym.VERB, yychar, yychar + lexema.length(), lexema);
            case "apples": case "coffee": case "water": case "books": case "book":
                return new Symbol(sym.NOUN, yychar, yychar + lexema.length(), lexema);
            default:
                return new Symbol(sym.ERROR, yychar, yychar + lexema.length(), lexema);
        }
    }
}
