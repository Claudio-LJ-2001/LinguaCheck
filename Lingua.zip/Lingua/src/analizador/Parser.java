package analizador;

import java_cup.runtime.*;
import java.io.*;

public class Parser {
    private Lexer lexer;
    private Symbol currentToken;

    public Parser(Lexer lexer) throws IOException {
        this.lexer = lexer;
        this.currentToken = lexer.next_token();
    }

    private void advance() throws IOException {
        currentToken = lexer.next_token();
    }

    private void match(int expected) throws IOException {
        if (currentToken.sym == expected) {
            advance();
        } else {
            throw new RuntimeException("Error de sintaxis. Se esperaba token: " + expected + " pero se encontró: " + currentToken.sym);
        }
    }

    public String parse() {
        try {
            match(sym.PRONOUN);
            match(sym.VERB);
            match(sym.NOUN);
            if (currentToken.sym != sym.EOF) {
                return "Error: la oración tiene contenido adicional no esperado.";
            }
            return "✔ Oración válida";
        } catch (Exception e) {
            return "Error: la estructura gramatical no es válida.";
        }
    }
}
