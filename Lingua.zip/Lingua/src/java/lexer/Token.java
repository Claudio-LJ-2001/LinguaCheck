package lexer;

public enum Token {
    PRONOUN,
    VERB,
    NOUN,
    ARTICLE,
    UNKNOWN
}