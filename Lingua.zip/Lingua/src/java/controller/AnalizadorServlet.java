package controller;

import model.AnalizadorGramatical;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/analizar")
public class AnalizadorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String oracion = request.getParameter("oracion");
        String resultado;

        try {
            resultado = AnalizadorGramatical.validar(oracion);
        } catch (Exception e) {
            resultado = "Error al analizar: " + e.getMessage();
        }

        request.setAttribute("resultado", resultado);
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
