package model;

import analizador.Lexer;
import analizador.Parser;
import analizador.sym;
import java.io.*;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

public class AnalizadorGramatical {

    private static Set<String> palabrasValidas = new HashSet<>();

    static {
        try {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(new FileReader("words.json"));
            JSONArray jsonArray = (JSONArray) obj;
            for (Object palabra : jsonArray) {
                palabrasValidas.add(palabra.toString().toLowerCase());
            }
        } catch (Exception e) {
            System.err.println("Error cargando words.json: " + e.getMessage());
        }
    }

    public static String validar(String oracion) {
        try {
            String[] palabras = oracion.trim().split("\\s+");
            StringBuilder errores = new StringBuilder();

            for (String palabra : palabras) {
                if (!palabrasValidas.contains(palabra.toLowerCase())) {
                    errores.append("Palabra no válida: ").append(palabra).append("\n");
                }
            }

            if (errores.length() > 0) {
                return errores.toString();
            }

            Lexer lexer = new Lexer(new StringReader(oracion));
            Parser parser = new Parser(lexer);
            String resultado = parser.parse();

            return resultado;
        } catch (Exception e) {
            return "Error general: " + e.getMessage();
        }
    }
}
